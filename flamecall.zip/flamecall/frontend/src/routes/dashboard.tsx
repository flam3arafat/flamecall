import React from "react";
// const Dashboard = React.lazy(
//     () => import('../components/Dashboard/dashboard'),
// )

var dashboardRoutes = [
  // { path: '/dashboard', name: 'Dashboard Page', component: <Dashboard /> }
];

export default dashboardRoutes;
